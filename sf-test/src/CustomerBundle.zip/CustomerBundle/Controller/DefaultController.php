<?php

namespace CustomerBundle\Controller;

use CustomerBundle\Entity\Customer;
use CustomerBundle\Form\CustomerType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Validator\Constraints\IsTrue;

class DefaultController extends Controller
{
    public function indexAction()
    {
        $customers = $this
            ->getDoctrine()
            ->getRepository('CustomerBundle:Customer')
            ->findAll();

        return $this->render('CustomerBundle:Default:index.html.twig', [
            'customers' => $customers,
        ]);
    }

    public function createAction(Request $request)
    {
        $customer = new Customer();

        $form = $this
            ->createForm(new CustomerType(), $customer, [
                'validation_groups' => ['registration']
            ])
            ->add('submit', 'submit');

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($customer);
            $em->flush();

            return $this->redirectToRoute('customer_index');
        }

        return $this->render(
            'CustomerBundle:Default:create.html.twig',
            [
                'form' => $form->createView(),
            ]
        );
    }

    public function detailAction($id)
    {
        $customer = $this
            ->getDoctrine()
            ->getRepository('CustomerBundle:Customer')
            ->find($id);

        if (!$customer) {
            throw $this->createNotFoundException(
                'Customer not found'
            );
        }

        return $this->render('CustomerBundle:Default:detail.html.twig', [
            'customer' => $customer,
        ]);
    }

    public function updateAction(Request $request)
    {
        $id = $request->attributes->get('id');

        // 1. Récupérer l'entité customer d'après l'ID
        $customer = $this
            ->getDoctrine()
            ->getRepository('CustomerBundle:Customer')
            ->find($id);

        // 2. Créer le formulaire (CustomerType)
        $form = $this
            ->createForm(new CustomerType(), $customer)
            ->add('submit', 'submit');

        // 3. Traitement (submit)
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($customer);
            $em->flush();

            return $this->redirectToRoute('customer_index');
        }

        return $this->render('CustomerBundle:Default:update.html.twig', [
            'customerId' => $id,
            // Passer la vue du formulaire pour l'afficher
        ]);
    }

    public function deleteAction(Request $request)
    {
        $id = $request->attributes->get('id');

        // 1. Récupérer l'entité customer d'après l'ID
        $customer = $this
            ->getDoctrine()
            ->getRepository('CustomerBundle:Customer')
            ->find($id);

        // 2. En utilisant le form builder,
        // créer un formulaire de confirmation
        // pour la suppression avec une case à cocher.
        $form = $this
            ->createFormBuilder()
            ->add('confirm', 'checkbox', [
                'label' => 'Confirmer la suppression ?',
                'required' => false,
                'constraints' => [
                    new IsTrue(),
                ]
            ])
            ->add('submit', 'submit')
            ->getForm();

        // 3. Si la case est cochée, supprimer le client
        //    Et rediriger vers la liste
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($customer);
            $em->flush();

            $this->redirectToRoute('customer_index');
        }

        return $this->render('CustomerBundle:Default:delete.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}
