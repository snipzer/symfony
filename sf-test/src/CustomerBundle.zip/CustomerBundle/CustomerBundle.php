<?php

namespace CustomerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CustomerBundle extends Bundle
{
}
