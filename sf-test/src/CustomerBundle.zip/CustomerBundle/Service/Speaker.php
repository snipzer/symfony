<?php

namespace CustomerBundle\Service;

class Speaker
{
    public function sayMyName()
    {
        return 'Heisenberg';
    }
}
